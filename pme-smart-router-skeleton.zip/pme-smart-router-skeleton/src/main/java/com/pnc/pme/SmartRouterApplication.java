package com.pnc.pme;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartRouterApplication {

    public static void main(String[] args) {
        SpringApplication.run(SmartRouterApplication.class, args);
    }
}
