package com.pnc.pme.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Placeholder endpoint for the initial commit. Real routing logic comes later;
 * for now this just confirms the app builds, deploys and responds.
 */
@RestController
@RequestMapping("/smart-router/v1")
public class RoutingController {

    @GetMapping("/ping")
    public String ping() {
        return "PME Smart Router is up";
    }
}
