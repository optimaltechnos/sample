package com.pnc.pme;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartRouterApplicationTests {

    @Test
    void contextLoads() {
        // Verifies the Spring context starts cleanly.
    }
}
