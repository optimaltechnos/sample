# PME Smart Router

Initial skeleton. Routing functionality is added in later commits; this commit just stands
up a buildable, deployable Spring Boot app with a single placeholder endpoint.

## Build
```
gradle wrapper --gradle-version 8.10.2   # one-time, generates the wrapper jar
./gradlew clean build
```

## Run
```
./gradlew bootRun
```

## Verify
```
curl http://localhost:8080/smart-router/v1/ping
# -> PME Smart Router is up
```
